<?php
require_once "../app/Bootstraps.php";
new \app\libs\Core();
