//Full Page js Initailizing
new fullpage('#wrapper', {
    autoscrolling: true,
    navigation: true,
    scrollingSpeed: 1000,
    navigationTooltips: ['Welcome', 'About Us', 'Our Teams', 'Contact Us'],
    showActiveTooltip: false
});

//Hamburger Toggle
const wrapper = document.querySelector('.main');
const hamburger = document.querySelector('.nav-toggle');

hamburger.addEventListener('click', () => {
    document.querySelector('.hamburger').classList.toggle('is-active');
    wrapper.classList.toggle('is-active');
    document.querySelector('#fp-nav').classList.toggle('is-active');
    document.querySelector('.hero').classList.toggle('is-froze');
});

//Nav Style on Scroll

const header = document.querySelector('.header');
const sectionOne = document.querySelector('.hero');

const sectionOneOptions = {
    rootMargin: '-200px 0px 0px 0px'
};

const sectionOneObserver = new IntersectionObserver(function(
        entries,
        sectionOneObserver
    ) {
        entries.forEach(entry => {
            if (!entry.isIntersecting) {
                header.classList.add('header-scrolled');
            } else {
                header.classList.remove('header-scrolled');
            }
        });
    },
    sectionOneOptions);

sectionOneObserver.observe(sectionOne);

//MouseOver Slider

document.addEventListener('DOMContentLoaded', function() {
    let mouseover = document.querySelector('.mouseover');
    let topLayer = wrapper.querySelector('.top');
    let handle = wrapper.querySelector('.handle');
    let skew = 0;
    let delta = 0;

    if (wrapper.className.indexOf('skewed') != -1) {
        skew = 1000;
    }

    mouseover.addEventListener('mousemove', function(e) {
        handle.style.left = e.clientX + 'px';

        topLayer.style.width = e.clientX + skew + 'px';
    });
});

//Dark Mode

let darkMode = localStorage.getItem('darkMode');
const darkModeToggle = document.querySelector('.darkmode');

const enableDarkMode = () => {
    document.body.classList.add('dark');
    document.body.classList.remove('light');

    localStorage.setItem('darkMode', 'enabled');
};

const disableDarkMode = () => {
    document.body.classList.remove('dark');
    document.body.classList.add('light');

    localStorage.setItem('darkMode', null);
};

if (darkMode === 'enabled') {
    enableDarkMode();
} else {
    document.body.classList.add('light');
}

darkModeToggle.addEventListener('click', () => {
    darkMode = localStorage.getItem('darkMode');

    if (darkMode != 'enabled') {
        enableDarkMode();
    } else {
        disableDarkMode();
    }
});