<?php
namespace app\libs;
class Db extends \app\libs\DAL
{

}