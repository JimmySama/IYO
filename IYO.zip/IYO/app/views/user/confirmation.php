<form action="<?php echo \app\config\Configs::$urlroot."User/Confirmation";?>" method="post">
<h5 class="form-title">Confirmation Here</h5>
<input required type="text" name="code"/>
<input type="submit" name="submit" value="Confirm" />
</form>