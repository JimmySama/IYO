<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>َThe Inspiration of Youth Organization</title>
    <link rel="shortcut icon" type="photo/jpg" href="<?php echo \app\config\Configs::$urlroot."assets/img/iyo.jpg"?>"/>
    <link rel="stylesheet" href="<?php echo \app\config\Configs::$urlroot."assets/css/styleforlogin.css"?>" />
</head>

<body>
<form class="box" action="<?php echo \app\config\Configs::$urlroot."User/Login";?>" method="post">
    <div class="avatar">
        <img src="<?php echo \app\config\Configs::$urlroot."assets/img/undraw_male_avatar_323b.svg" ?>" alt="Avatar" class="avatar-img" />
    </div>

    <h5 class="form-title">SIGN IN</h5>
    <input required type="text" name="email" placeholder="Email" autocomplete="email"
        <?php echo !empty($data['email_error']) ? "is-invalid" : '';?>/>
    <?php echo !empty($data["email_error"]) ? $data["email_error"] : '';?>

    <input required type="password" name="password" placeholder="Password"
        <?php echo !empty($data['password_error']) ? "is-invalid" : ''; ?>/>
    <span class="text-danger"><?php echo !empty($data['password_error']) ? $data['password_error'] : '';?></span>

    <input type="submit" name="submit" value="SIGN IN" />

    <h5 class="login-title">
        Create an Account?
    </h5>
    <a href="<?php echo \app\config\Configs::$urlroot."User/SignUp"?>" class="login-link"><u>Sign Up </u></a>
</form>

<button id="toggle">dark mode</button>
<script src="<?php echo \app\config\Configs::$urlroot."assets/js/app.js"?>"></script>
</body>

</html>