<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link href="https://fonts.googleapis.com/css?family=Oleo+Script|Poppins|Source+Serif+Pro&display=swap" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo \app\config\Configs::$urlroot."assets/css/fullpage.min.css"?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo \app\config\Configs::$urlroot."assets/css/pages/home.css"?>"/>
    <link rel="shortcut icon" type="photo/jpg" href="<?php echo \app\config\Configs::$urlroot."assets/img/iyo.jpg"?>"/>
    <title>The Inspiration of Youth Organization</title>
</head>

<body>

<nav>
    <ul class="nav-list ">
        <a href="<?php echo \app\config\Configs::$urlroot?>" class="nav-link">
            <li class="nav-item nav-active">Home</li>
        </a>
        <?php if (\app\config\Configs::getUserSession("Current_User") == false &&
        \app\config\Configs::getUserSession("Current_Admin") == false): ?>
            <a href="<?php echo \app\config\Configs::$urlroot."User/Login"?>" class="nav-link">
                <li class="nav-item">Login</li>
            </a>
            <a href="<?php echo \app\config\Configs::$urlroot."User/SignUp"?>" class="nav-link">
                <li class="nav-item">Sign Up</li>
            </a>
            </a> <a href="<?php echo \app\config\Configs::$urlroot ?>" class="nav-link">
                <li class="nav-item">Member</li>
            </a>
        <?php else: ?>

            <a href="<?php echo \app\config\Configs::$urlroot."Event"?>" class="nav-link">
                <li class="nav-item">Events</li>
            </a>
            <a href="<?php echo \app\config\Configs::$urlroot."User/Logout"?>" class="nav-link">
                <li class="nav-item">Logout</li>
            </a>
            </a> <a class="nav-link">
                <?php if (\app\config\Configs::getUserSession("Current_User")) :?>
                <li class="nav-item"><?php echo \app\config\Configs::getUserSession("Current_User");?>

                </li>
                <?php else: ?>
                    <a href="<?php echo \app\config\Configs::$urlroot."Event/Create"?>" class="nav-link">
                    <li class="nav-item">Create Event</li>
                </a>
            <li class="nav-item"><?php echo \app\config\Configs::getUserSession("Current_Admin");?>

            </li>

            <?php endif; ?>
            </a>
        <?php endif; ?>

        <a class="nav-link darkmode">
            <li class="nav-item">
                Toggle Dark Mode
            </li>
        </a>
    </ul>
</nav>

<main class="main ">
    <header class="header">
        <div class="logo">IYO</div>
        <div class="username">
          

        </div>
        <a class="nav-toggle">
            <div class="hamburger">
                <div class="bars"></div>
            </div>
        </a>
    </header>
    <div id="wrapper">
        <div class="section hero">
            <div class="container--fluid mouseover ">
                <div class="welcome">
                    <h5 class="welcome__text">welcome</h5>
                </div>
                <div class="quote">
                    <h5 class="quote--script heading--tertiary m-b--sm">
                        Before you code, think. Before you write, read. Before you speak, listen. Before you comment, reflect. Before you release, test
                    </h5>
                    <div class="t-right">
                        <h5 class="quote--person ">Addy Osmani</h5>
                    </div>
                </div>
                <div class="layer top">
                    <div class="content-wrap">
                        <div class=" content-body"></div>
                    </div>
                </div>
                <div class="layer bottom">
                    <div class="content-wrap">
                        <div class=" content-body"></div>
                    </div>
                </div>
                <div class="handle"></div>
            </div>
        </div>
        <div class="section about"></div>
        <div class="section teams"></div>
        <div class="section footer"></div>
    </div>
</main>
<script src="<?php echo \app\config\Configs::$urlroot."assets/js/fullpage.min.js"?>"></script>
<script src="<?php echo \app\config\Configs::$urlroot."assets/js/home.js"?>"></script>
</body>

</html>