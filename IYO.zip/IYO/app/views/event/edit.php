<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link href="https://fonts.googleapis.com/css?family=Oleo+Script|Poppins|Source+Serif+Pro&display=swap" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?php echo \app\config\Configs::$urlroot."assets/css/admin.css"?>"/>
    <link rel="shortcut icon" type="photo/jpg" href="<?php echo \app\config\Configs::$urlroot."assets/img/iyo.jpg"?>"/>
    <title>The Inspiration of Youth Organization</title>
</head>

<body>
<nav>
    <ul class="nav-list ">
        <a href="<?php echo \app\config\Configs::$urlroot?>" class="nav-link">
            <li class="nav-item nav-active">Home</li>
        </a>
        <a href="<?php echo \app\config\Configs::$urlroot."Event"?>" class="nav-link">
            <li class="nav-item">Events</li>
        </a>
        <a href="<?php echo \app\config\Configs::$urlroot."User/Logout"?>" class="nav-link">
            <li class="nav-item shit">Logout</li>
        </a>

        <?php if (\app\config\Configs::getUserSession("Current_User")) :?>
            <a class="nav-link">
                <li class="nav-item"><?php echo \app\config\Configs::getUserSession("Current_User");?>

                </li>
            </a>
        <?php else: ?>
            <a href="<?php echo \app\config\Configs::$urlroot."Event/Create"?>" class="nav-link">
                <li class="nav-item">Create Event</li>
            </a>
            <a class="nav-link">
                <li class="nav-item"><?php echo \app\config\Configs::getUserSession("Current_Admin");?>

                </li>
            </a>


        <?php endif; ?>

        <a class="nav-link ">
            <li class="nav-item darkmode">
                <div class="item-text" style="display: inline-block;"></div>
                <div class="darkmode-toggler"></div>
            </li>
        </a>
    </ul>
</nav>

<main class="main ">
    <header class="header">
        <div class="logo">IYO</div>
        <div class="username"></div>
        <a class="nav-toggle">
            <div class="hamburger">
                <div class="bars"></div>
            </div>
        </a>
    </header>

    <div id="wrapper">
        <div class="add_post">
            <h3 class=" heading_post">Edit Event</h3>
            <form action="<?php echo \app\config\Configs::$urlroot."Event/Edit/".$data["event"]->eventid;?>" method="post" enctype="multipart/form-data">
                <div class="formgroup">
                    <h5 class="heading--tertiary formgroup__title">Title</h5>
                    <label for="title">
                        <input type="text" name="title" class="input--text" value="<?php echo $data["event"]->title;?>" required>
                    </label>
                </div>

                <div class="formgroup">
                    <h5 class="heading--tertiary formgroup__title">Description</h5>
                    <label for="desp">
                            <textarea name="desp"  cols="30" rows="10" required>
                            <?php echo $data["event"]->description;?>
                        </textarea>
                    </label>
                </div>

                <div class="formgroup">
                    <h5 class="heading--tertiary formgroup__title">Speaker</h5>
                    <label for="speaker">
                        <input type="text" name="speaker" class="input--text" value="<?php echo $data["event"]->speaker;?>" required>
                    </label>
                </div>

                <div class="formgroup">
                    <h5 class="heading--tertiary formgroup__title">Date</h5>
                    <label for="date">
                        <input type="text" name="date" class="input--text" value="<?php echo $data["event"]->eventtime;?>" required>

                    </label>

                </div>

                <div class="formgroup">
                    <h5 class="heading--tertiary formgroup__title">Event Detail</h5>
                    <label for="detail">
                        <textarea name="content" id="" cols="30" rows="20" required>
                              <?php echo $data["event"]->content;?>
                        </textarea>
                    </label>
                </div>

                <div class="formgroup">
                    <label for="image">
                        <input type="file" name="file" class="choose-img" placeholder="Choose File" required>
                        <!--<button type="button"  class="custom-button">CHOOSE A FILE</button>
                        <span class="custom-text">No file chosen,yet.</span>-->
                    </label>
                </div>
                <button type="submit" name="submit" class="create_post">Edit</button>
            </form>
        </div>
    </div>

    </div>
</main>
<div class="cursor"></div>

<script src="<?php echo \app\config\Configs::$urlroot."assets/js/admin.js"?>"></script>
</body>

</html>