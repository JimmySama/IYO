<?php
class UserModel
{
    private $db;
    public function __construct()
    {
        $this->db = new \app\libs\Db();
    }
    public function getUserByEmail($email)
    {
        $this->db->query("SELECT * FROM user WHERE email=:email");
        $this->db->bind(":email",$email);
        return $this->db->singleSet();
    }
    public function getUserByName($name)
    {
        $this->db->query("SELECT * FROM user WHERE name=:name");
        $this->db->bind(":name",$name);
        return $this->db->singleSet();
    }
    public function registerUser($name,$email,$password)
    {
        $cost = mt_rand(1,5);
        $password = password_hash($password,PASSWORD_BCRYPT,['cost' => $cost]);
        date_default_timezone_set("Asia/Rangoon");
        $created_at = date("Y-m-d H:i:s",time());
        $this->db->query("INSERT INTO user (name,email,password,created_at) VALUES (:name,:email,:password,:created_at)");
        $this->db->bind(":name",$name);
        $this->db->bind(":email",$email);
        $this->db->bind(":password",$password);
        $this->db->bind(":created_at",$created_at);
        return $this->db->execute();
    }
    public function updateUser($email,$state)
    {
        $this->db->query("UPDATE user SET state=:state WHERE email=:email");
        $this->db->bind(":state",$state);
        $this->db->bind(":email",$email);
        return $this->db->execute();
    }
}