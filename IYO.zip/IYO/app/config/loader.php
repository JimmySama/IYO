
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <link rel="stylesheet" href="../css/pages/lil-noti.css" />
    <title>Document</title>
</head>
<body>
<div class="wrapper">
    <button class="btn">Click to see Magic</button>
</div>
<div class="noti">Ko May Ko Loe</div>

<script src="../js/lil_noti.js"></script>
</body>
</html>
