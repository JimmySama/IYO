<?php
class Admin extends \app\libs\Controller
{
    public function __construct()
    {

    }

}