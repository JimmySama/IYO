<?php
class Admin extends \app\libs\Controller
{
    public function __construct()
    {
        $this->adminmodel = $this->model("AdminModel");
        $this->eventmodel = $this->model("EventModel");
    }
    public function notification()
    {
        if (\app\config\Configs::getUserSession("Current_Admin") == false)
        {
            \app\config\Configs::redirectPage(\app\config\Configs::$urlroot);
        }
        else
        {

            if($_SERVER['REQUEST_METHOD'] == "GET")
            {
                $data = [
                "event" => '',
                "users" => '',

                ];


                $data['event'] = $this->adminmodel->getNotificationsByDistinct();
                $data['users'] = $this->adminmodel->getAllNotifications();


                $this->view("admin/notification",$data);
            }
            else {
                if(isset($_POST['send']))
                {
                    if($this->adminmodel->sendReminderNotification($_POST['email']))
                    {
                        if($this->adminmodel->updateNotificationState($_POST['notiid']))
                        \app\config\Configs::redirectPage(\app\config\Configs::$urlroot."Admin/Notification");
                    }
                }
                if(isset($_POST['remove']))
                {
                    if($this->adminmodel->deleteNotification($_POST['notiid']))
                    {
                        \app\config\Configs::redirectPage(\app\config\Configs::$urlroot."Admin/Notification");
                    }
                }
            }
        }

    }

}